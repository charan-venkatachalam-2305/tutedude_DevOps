# Menu-driven calculator

# Add Function
def add(a, b):
    return a + b

# Subtract Function
def subtract(a, b):
    return a - b

# Multiply Function
def multiply(a, b):
    return a * b

# Divide Function
def divide(a, b):
    # Try Block for Division
    try:
        return a / b
    # Except Block to handle Divide by Zero error
    except ZeroDivisionError:
        return "Error: Cannot divide by zero."

# While Loop to Display Calculator menu until 5 is chosen to exit
while True:

    print("\n===== Simple Calculator =====")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Exit")

    # User Inputto get choice fromMenu
    choice = input("Enter your choice (1-5): ")

    # If user chooses 5, program breaks/ends
    if choice == "5":
        print("Calculator closed. Goodbye!")
        break

    # Using list to check if user has chosen a listed option
    if choice in ["1", "2", "3", "4"]:

        # User Input for numbers
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        # If - Elif conditions for the operations
        if choice == "1":
            result = add(num1, num2)

        elif choice == "2":
            result = subtract(num1, num2)

        elif choice == "3":
            result = multiply(num1, num2)

        elif choice == "4":
            result = divide(num1, num2)

        # Printing result
        print("Result:", result)

    else:
        print("Invalid choice. Please select a number from 1 to 5.")