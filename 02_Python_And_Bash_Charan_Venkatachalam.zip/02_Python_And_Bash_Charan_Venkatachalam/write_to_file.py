file = open("text_file.txt", "w")

file.write("Hello, Linux!\n")
file.write("I love biking.\n")
file.write("I ride a Sand Brown Honda CB 350!.\n")

file.close()