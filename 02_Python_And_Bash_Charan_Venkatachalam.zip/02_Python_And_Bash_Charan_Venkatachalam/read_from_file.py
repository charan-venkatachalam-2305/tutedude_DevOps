file = open("text_file.txt", "r")

content = file.read()

print(content)

file.close()