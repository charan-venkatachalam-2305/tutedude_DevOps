students = {"stud1": 85, "stud2": 92, "stud3": 76}

print("1. Add student")
print("2. Update student")
print("3. Print all students")

choice = input("Enter your choice: ")

if choice == "1":
    name = input("Enter student name: ")
    grade = int(input("Enter grade: "))

    students[name] = grade
    print("Student added.")

elif choice == "2":
    name = input("Enter student name: ")

    if name in students:
        grade = int(input("Enter new grade: "))
        students[name] = grade
        print("Grade updated.")
    else:
        print("Student not found.")

elif choice == "3":
    print("Student Grades:")

    for name, grade in students.items():
        print(name, ":", grade)

else:
    print("Invalid choice.")